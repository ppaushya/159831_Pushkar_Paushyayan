package day3demo;

import java.util.Scanner;

public class MinSum2d {

	Scanner sc=new Scanner(System.in);
	int row,col;
	public void getSize()
	{
		System.out.println("Enter num of row and col: ");
		row=sc.nextInt();
		col=sc.nextInt();
		
	}
	public void getElem(int[][] arr)
	{
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
	}
	public void print(int[][] arr)
	{
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
	}
	public int sum(int[][] arr)
	{
		int sum;
		int index=0;
		int small=999;
		for(int i=0;i<row;i++)
		{
			sum=0;
			for(int j=0;j<col;j++)
			{
				sum=sum+arr[i][j];
			}
			if(sum<small)
			{
				small=sum;
				index=i;
			}
			System.out.println();
		}
		return index;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		MinSum2d obj=new MinSum2d();
		
		obj.getSize();
		int[][] arr=new int[obj.row][obj.col];
		System.out.println("Enter Elements:");
		obj.getElem(arr);
		System.out.println("Array is:");
		obj.print(arr);
		System.out.println("The set having minimum set is:");
		int i=obj.sum(arr);
		
			for(int j=0;j<obj.col;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			
		sc.close();

	}

}
