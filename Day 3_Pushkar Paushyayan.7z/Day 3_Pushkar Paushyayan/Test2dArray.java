package day3demo;

import java.util.Scanner;

public class Test2dArray {
	Scanner sc=new Scanner(System.in);
	int row,col;
	int[][] arr;
	public int getSize()
	{
		System.out.println("Enter num of row and col: ");
		row=sc.nextInt();
		col=sc.nextInt();
		if(row!=col)
		{
			return 0;
		}
		else
			return 1;
	}
	
	public void print(int[][] arr)
	{
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
	}
	public void upperT(int[][] arr)
	{
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				if(i<=j)
					System.out.print(arr[i][j]+"\t");
				else
					System.out.print(" \t");
			}
			System.out.print("\n");
		}
	}
	public void lowerT(int[][] arr)
	{
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				if(i>=j)
					System.out.print(arr[i][j]+"\t");
				
			}
			System.out.print("\n");
		}
	}
	public void transpose(int[][] arr)
	{
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				System.out.print(arr[j][i]+"\t");
			}
			System.out.print("\n");
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Test2dArray obj=new Test2dArray();
		int[][] arr;
		char choice='y';
		do {
			int x=obj.getSize();
			switch(x)
			{
			case 0:
				choice='n';
				System.out.println("Enter size again");
				break;
			case 1:
				System.out.println("Enter the elements");
				arr=new int[obj.row][obj.col];
				
				for(int i=0;i<obj.row;i++)
				{
					for(int j=0;j<obj.col;j++)
					{
						arr[i][j]=sc.nextInt();
					}
				}
				System.out.println("Elements are");
				obj.print(arr);
				System.out.print("\n");
				obj.upperT(arr);
				System.out.print("\n");
				obj.lowerT(arr);
				System.out.print("\n");
				obj.transpose(arr);
				break;
			}
		}while(choice!='y'||choice!='Y');
		sc.close();
	}

}
