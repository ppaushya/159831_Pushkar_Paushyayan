package boot;

import java.sql.ResultSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import model.Account;
import model.Address;
import model.Customer;
import model.Transaction;
import service.CustomerServiceImpl;
import service.ICustomerService;
import view.UserInteraction;
public class MainClass {
	
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args) {

		ICustomerService customerService=new CustomerServiceImpl();
		UserInteraction userInteraction=new UserInteraction();
		
		Customer customer=new Customer();
		Address address =new Address();
		Account account = new Account();
		Transaction transaction = new Transaction();
		
		System.out.println("\t\t--------< Welcome to Community Bank >--------");
		int  choice;
        String option;
		do {
		System.out.println("1.) Create Customer");
		System.out.println("2.) Create Account");
		System.out.println("3.) Print Customer Details with Account info");
		System.out.println("4.) Do Transaction");
        System.out.println("5.) Transaction Summary");
        System.out.println("6.) Exit");
		System.out.println(" Make Your Choice:");
		choice=sc.nextInt();
				
			switch(choice) {
			case 1:
				customer=userInteraction.getCustomerDetails();
				address=userInteraction.getAddressDetails(customer);
				
				Customer customer1=userInteraction.createCustomer(customer);
				Address address1=userInteraction.createAddress(customer, address);
				
				if(customer1!=null && address1 != null)
				{
					Set<Customer> customers= customerService.getAllCustomer();
					Set<Address> addresses=customerService.getAllAddress();
					userInteraction.printDetails(customers,addresses);
				}
				else
				{
					System.out.println("Table does not exists.");
				}
				break;
			case 2:account=userInteraction.createAccount();
			break;
				
			case 3:
				System.out.println("Enter customer Id: ");
				int customerId=sc.nextInt();
				userInteraction.printAccountDetails(customerId);
				break;
			case 4:
				break;
			case 5:
				break;
			case 6:
				System.exit(0);
			}
			System.out.println("Enter [y/Y] to continue:");
			option=sc.next();
		}while(option.charAt(0)=='y' || option.charAt(0)=='Y');
	}

}
