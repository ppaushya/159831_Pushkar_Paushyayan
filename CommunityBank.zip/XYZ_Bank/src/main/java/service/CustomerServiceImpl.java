package service;

import java.sql.ResultSet;
import java.util.List;
import java.util.Set;

import dao.ICustomerDao;
import dao.customerDaoImpl;
import model.Address;
import model.Customer;

public class CustomerServiceImpl implements ICustomerService {

	@Override
	public Customer createCustomer(Customer customer) {

		ICustomerDao customerDao=new customerDaoImpl();
		return customerDao.createCustomer(customer);
	}

	@Override
	public Address createAddress(Customer customer, Address address) {

		ICustomerDao customerDao=new customerDaoImpl();
		return customerDao.createAddress(customer,address);
	}

	@Override
	public Set<Customer> getAllCustomer() {

		ICustomerDao customerDao=new customerDaoImpl();
		return customerDao.getAllCustomer();
	}

	@Override
	public Set<Address> getAllAddress() {
		ICustomerDao customerDao=new customerDaoImpl();
		return customerDao.getAllAddress();
	}
	

}
