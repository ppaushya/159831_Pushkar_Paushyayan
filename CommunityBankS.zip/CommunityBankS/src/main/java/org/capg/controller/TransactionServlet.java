package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

/**
 * Servlet implementation class Transaction
 */
@WebServlet("/Transaction")
public class TransactionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		int customerId=(Integer)(session.getAttribute("custId"));
	
		int accNo=Integer.parseInt(request.getParameter("account"));
		
		
		String description=request.getParameter("description");
		Transaction transaction=new Transaction();
		transaction.setFromAccount(accNo);
		transaction.setToAccount(0);
		transaction.setDescription(description);
		transaction.setTransactionType(request.getParameter("creditOrDebit"));
		transaction.setAmount(Double.parseDouble(request.getParameter("amount")));
		transaction.setTransactionDate(LocalDate.now());
		Customer customer=new Customer();
		customer.setCustomerId(customerId);
		transaction.setCustomer(customer);
		
		ILoginService loginService=new LoginServiceImpl();
		if(loginService.addTransactionDetails(transaction))
		{
			System.out.println("Transaction Successful");
		}
		
	}

}
