package org.cap.controller;

import org.cap.model.Register;
import org.cap.model.loginPojo;
import org.cap.service.IloginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.ModelMap;

@Controller
public class loginController {

	@Autowired
	private IloginService loginService;
	
	@RequestMapping("/")
	public ModelAndView getIndexpage()
	{
		return new ModelAndView("index", "login", new loginPojo());
	}
	
	@RequestMapping("/validateLogin")
	public String ValidateLogin(ModelMap map,@ModelAttribute("login") loginPojo loginpojo) {
		
		if(loginService.isValidLogin(loginpojo))
		{ 
			map.addAttribute("register", new Register());
			return "register"; }
		else
		{
		return "redirect:/";
		}
}
}

