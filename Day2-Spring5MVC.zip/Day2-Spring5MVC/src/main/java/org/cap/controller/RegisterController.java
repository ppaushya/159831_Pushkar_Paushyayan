package org.cap.controller;

import javax.validation.Valid;

import org.cap.model.Register;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RegisterController {

	//@RequestMapping(value="/registrationDetail",method=RequestMethod.POST)
	@PostMapping("/registrationDetail")
	public String registerDetails(@Valid @ModelAttribute("register")Register register,
			BindingResult result)

	{
		// binding result to store error
		if(result.hasErrors())
		
			return "register";
		
      System.out.println(register);

			return "success";

	}
}
