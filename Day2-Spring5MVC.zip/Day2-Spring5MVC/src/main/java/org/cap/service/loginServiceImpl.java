package org.cap.service;

import org.cap.Dao.ILoginDao;
import org.cap.model.loginPojo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService")
public class loginServiceImpl implements IloginService {

	
	//@Autowired
	//private ILoginDao loginDao;
	
	
	@Override
	public boolean isValidLogin(loginPojo loginpojo) {
		if(loginpojo.getUserName().equals("tom") && loginpojo.getUserPassword().equals("tom123"))
		return true;
		return false;
	}

}
