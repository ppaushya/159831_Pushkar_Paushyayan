package org.cap.service;

import org.cap.model.loginPojo;

public interface IloginService {

	public boolean isValidLogin(loginPojo loginpojo);

}
