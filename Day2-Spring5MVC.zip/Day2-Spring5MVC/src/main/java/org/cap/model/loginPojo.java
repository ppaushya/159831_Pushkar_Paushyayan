package org.cap.model;

public class loginPojo {

	private String userName;
	private String userPassword;
	
	public loginPojo()
	{
		
	}
	public loginPojo(String userName, String userPassword) {
		super();
		this.userName = userName;
		this.userPassword = userPassword;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	@Override
	public String toString() {
		return "loginPojo [userName=" + userName + ", userPassword=" + userPassword + "]";
	}
	
	
}
