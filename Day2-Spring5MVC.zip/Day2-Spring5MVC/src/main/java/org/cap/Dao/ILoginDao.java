package org.cap.Dao;

import org.cap.model.loginPojo;

public interface ILoginDao {

	public boolean isValidLogin(loginPojo loginPojo);
}
