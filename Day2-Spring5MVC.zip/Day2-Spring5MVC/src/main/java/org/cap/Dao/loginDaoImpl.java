package org.cap.Dao;

import org.cap.model.loginPojo;

public class loginDaoImpl implements ILoginDao {

	@Override
	public boolean isValidLogin(loginPojo loginPojo) {
		
		return false;
	}

}
