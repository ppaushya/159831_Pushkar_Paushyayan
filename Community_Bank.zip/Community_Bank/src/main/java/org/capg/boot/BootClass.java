package org.capg.boot;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;
import org.capg.view.UserInteraction;

public class BootClass {

	static Scanner scanner=new Scanner(System.in);
	
	public static void main(String[] args) {
		ICustomerService customerService=new CustomerServiceImpl();
		UserInteraction userInteraction=new UserInteraction();
		
		List<Transaction> summary=new ArrayList<>();
		
		int  choice;
		String option;
		do {
		System.out.println("1.Create Customer");
		System.out.println("2.List Customers");
		System.out.println("3.Create Account");
		System.out.println("4.Print Account Details");
		System.out.println("5.Do Transactions");
		System.out.println("6.Print Transactions");
		System.out.println("Enter Your choice:");
		choice=scanner.nextInt();
		int count=customerService.getAllCustomers().size();	
			switch(choice) {		
			case 1:
				
			
			//int count=customerService.getAllCustomers().size();
				
				Customer customer=userInteraction.getCustomerDetails();
				customerService.createCustomer(customer);
				
				
				if(count==customerService.getAllCustomers().size())
					userInteraction.printError("Customer Creation Error! Please Try Again!");
					
				
				break;
			case 2:
				
				List<Customer> customers= customerService.getAllCustomers();
				userInteraction.printCustomers(customers);
				break;
			
				
			case 3:
				List<Customer> customers1= customerService.getAllCustomers();
				//System.out.println(customers1);
				//Customer cust=userInteraction.findCustomer(customers1);
				userInteraction.printCustomers(customers1);
				Account account=new Account();
				System.out.println("Choose CustomerId");
				int customerId = scanner.nextInt();
			Customer cust=customerService.isFound(customerId);
				
				
				if(cust==null)
				{
					System.out.println("Customer does not exist");
				}
				
						 account=userInteraction.promptAccountDetails();
						System.out.println(account);
						customerService.setAccountDetails(cust,account);
						
						
				
				
				break;
			case 4:
				List<Customer> custome= customerService.getAllCustomers();
				userInteraction.printCustomers(custome);
				System.out.println("Choose CustomerId");
				int customerId1 = scanner.nextInt();
			Customer cust1=customerService.isFound(customerId1);
				
				
				if(cust1==null)
				{
					System.out.println("Customer does not exist");
				}
				userInteraction.customerAccounts(cust1);
				break;
			
			case 5:
				summary=(userInteraction.performTransaction());
				System.out.println("Transactions done successfully");
				
				break;
			case 6:
				userInteraction.printTransaction(summary);
				break;
			default:
				System.out.println("Sorry! Invalid Choice");
				System.exit(0);
				break;
				
			}
			System.out.println("Do you wish to contine?[y|n]:");
			option=scanner.next();
			
		}while(option.charAt(0)=='y' || option.charAt(0)=='Y');
		
		System.out.println("Your Wallet is Updated");
		
		
	}

}
