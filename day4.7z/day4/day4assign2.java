import static java.lang.System.out;
import java.util.Scanner;
public class day4assign2 {

	public void LetterCapitalize(String str) {
		
		int n=str.length();
		int temp;
		char[] ch=str.toCharArray();
		for(int i=0;i<n;i++) {
			if(ch[i]==' ') {
				temp=ch[i+1]-32;
				ch[i+1]=(char)temp;
			}
			else if(i==0) {
				temp=ch[i]-32;
			ch[i]=(char)temp;
			}
		}
		for(char t:ch) {
			out.print(t);
		}
		
	}
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		String str1=new String();
		out.println("Enter the String");
		str1=sc.nextLine();
		day4assign2 d=new day4assign2();
		d.LetterCapitalize(str1);
		sc.close();
	}

}
