import java.util.Scanner;

public class Day_4_Assignment_1 {

	public void primefact(int n)
	{
		while(n%2==0)
		{
			System.out.print(2+" ");
			n=n/2;
		}
		
		for(int i=3;i<=Math.sqrt(n);i+=2)
		{
			while(n%i==0)
			{
				System.out.print(i+" ");
				n=n/i;
			}
		}
		if(n>2)
		{
			System.out.print(n);
			
		}
		Scanner sc = new Scanner(System.in);
		
	}
	public static void main(String[] args) {
	
            int n;
           Scanner sc = new Scanner(System.in);
           n=sc.nextInt();
           
           Day_4_Assignment_1 o=new Day_4_Assignment_1();
           o.primefact(n);
         
	}

}
