package practice;

public class CheckException1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1=100;
//		int num2=0;
		String num2="10s";
		int result = 0;
		try
		{
//		result=num1/num2;
			result=num1/Integer.parseInt(num2);
		}catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
		}
		catch(NumberFormatException e)
		{
			System.out.println(e.getMessage());
		}
		finally//Guaranteed execution
		{
			System.out.println("Finally Block State");
		}
//		System.out.println("Result: "+result);
		
	}

}
//cannot be shuffled, compile time error
//try can be with finally only and catch only,here JVM will handle the exception
//close shared resources in finally, bcoz it is always executed
//
