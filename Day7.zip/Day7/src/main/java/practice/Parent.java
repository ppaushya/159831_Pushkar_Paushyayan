package practice;

import java.io.IOException;

public class Parent {

	
	void msg() 
	  {  
	    System.out.println("Parent-msg method");  
	  } 
}
