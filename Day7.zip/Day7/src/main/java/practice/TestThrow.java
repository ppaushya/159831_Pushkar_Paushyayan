package practice;
//throw exception object explicitly

public class TestThrow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String num=args[2];
		if(num!=null)
		{
			int n=Integer.parseInt(num);
			int ans=n+90;
			System.out.println("Ans: "+ans);
		}
		else
		{
			try {
			throw new NullPointerException("U got an error");
			}catch(NullPointerException e) {
				
			}
		}
	}

}
