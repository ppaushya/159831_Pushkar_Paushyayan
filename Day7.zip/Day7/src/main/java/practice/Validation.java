package practice;
import java.util.*;
import java.util.regex.*;
public class Validation {

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String empId;
		
		
		empId=sc.next();
		
		/*if(empId.matches("\\d{5}_(FS|TS|IN)"))
		{
			System.out.println("Valid");
		}
		else
			System.out.println("try again");*/
		
		Pattern pattern=Pattern.compile("\\d{5}_(FS|TS|IN)");
		Matcher matcher=pattern.matcher(empId);
		System.out.println(matcher.find());
	}

}
