package practice;
//throws...give readability
//informing JVM 
//comma seperated exceptions
//listing of exceptions in throws inside method

public class CheckException3 {

	public static void main(String[] args) {
		Calculation calculation=new Calculation();
		try
		{
			calculation.calculate();
			
		}catch(ArithmeticException e){
			
		}
		
	}

}
