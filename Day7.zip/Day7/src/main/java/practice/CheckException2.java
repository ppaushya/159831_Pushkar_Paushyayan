package practice;
//multiple try
public class CheckException2 {

	public static void main(String[] args) {
		Integer num1=100;
		Integer num2=null;
		Integer ans=null;
		int result;
		try 
		{
			 ans =num1+num2;
			System.out.println("Answer: "+ans);
			try 
			{
				//String num="80s";
				String num="80";
				result=num1/Integer.parseInt(num);
				System.out.println("Result: "+result);
			}catch (NullPointerException|NumberFormatException e)
			{
				System.out.println(e.getMessage());
			}
			System.out.println("outer try block");
		}catch (ArithmeticException|NullPointerException e) {
			e.printStackTrace();
		}
		
		System.out.println("Answer: "+ans);

	}

}
