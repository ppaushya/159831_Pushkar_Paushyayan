package practice;
import java.io.*;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file=new File("C:\\SAMPLE\\data.txt");
		try {
			FileInputStream inputStream=new FileInputStream(file);
			
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}

}
