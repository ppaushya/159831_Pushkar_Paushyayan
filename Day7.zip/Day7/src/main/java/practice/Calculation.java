package practice;
//throws
public class Calculation {

	public void calculate() throws NullPointerException,NumberFormatException,ArithmeticException
	{
		Integer num1=100;
		Integer num2=null;
		Integer ans=null;
		int result;
			 ans =num1+num2;
			System.out.println("Answer: "+ans);
				//String num="80s";
				String num="80";
				result=num1/Integer.parseInt(num);
				System.out.println("Result: "+result);
			System.out.println("outer try block");
		System.out.println("Answer: "+ans);
	}
}
