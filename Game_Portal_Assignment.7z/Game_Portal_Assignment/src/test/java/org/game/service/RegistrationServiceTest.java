package org.game.service;

import static org.junit.Assert.*;

import org.game.dao.IRegistrationDao;
import org.game.exception.InvalidAgeException;
import org.game.model.Registration;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class RegistrationServiceTest {

	@Mock
	IRegistrationDao registrationDao;
	
	static IRegistrationService registrationService;
	
	@Before
	public void setUpBeforeClass(){
		MockitoAnnotations.initMocks(this);
		registrationService = new RegistrationServiceImpl(registrationDao);
	}

	@Test(expected=IllegalArgumentException.class)
	public void test_createRegistration_method_with_null() throws InvalidAgeException {
		Registration registration = null;
		
		registrationService.createRegistration(registration);
	}
	
	@Test(expected=InvalidAgeException.class)
	public void test_createRegistration_method_with_invalid_age() throws InvalidAgeException {
		Registration registration = new Registration(100, "Tom", "9876598765", 1000, 5, 1000);
		
		registrationService.createRegistration(registration);
	}

	@Test
	public void test_createRegistration_method_with_success() throws InvalidAgeException {
		Registration registration = new Registration(100, "Tom", "9876598765", 1000, 25, 1000);
		
		Mockito.when(registrationDao.createRegistration(registration)).thenReturn(registration);
		registrationService.createRegistration(registration);
		
		Mockito.verify(registrationDao).createRegistration(registration);
	}
	
	@Test
	public void test_getActualFees_method(){
		RegistrationServiceImpl serviceImpl = new RegistrationServiceImpl();
		assertEquals(1000, serviceImpl.getActualFees(1000, 10),0.0);
		assertEquals(1100, serviceImpl.getActualFees(1000, 20),0.0);
		assertEquals(1200, serviceImpl.getActualFees(1000, 30),0.0);
		assertEquals(1300, serviceImpl.getActualFees(1000, 60),0.0);
		assertEquals(1200, serviceImpl.getActualFees(1000, 50),0.0);
		assertEquals(1100, serviceImpl.getActualFees(1000, 25),0.0);
		assertEquals(1000, serviceImpl.getActualFees(1000, 18),0.0);
	}
}
