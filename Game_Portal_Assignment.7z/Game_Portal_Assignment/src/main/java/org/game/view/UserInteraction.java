package org.view;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.game.dao.RegistrationDaoImpl;
import org.game.exception.InvalidAgeException;
import org.game.model.Registration;
import org.game.service.IRegistrationService;
import org.game.service.RegistrationServiceImpl;

public class UserInteraction {

	static Scanner scanner = new Scanner(System.in);
	final static Logger logger=Logger.getLogger(RegistrationDaoImpl.class);
	
	public static int getTaskChoiceFromUser() {
		int choice=0;
		while(choice<1 || choice>2) {
			System.out.println();
			System.out.println("----------------------------------");
			System.out.println("1. Register for Game portal");
			System.out.println("2. Exit");
			System.out.println("Enter your choice[1,2]: ");
			choice = scanner.nextInt();
			if(choice<1 || choice>2) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		logger.debug("choice "+choice+" selected.");
		return choice;
	}
	
	public static boolean getRepeatConfirmation() {
		boolean shouldRepeat = false;
		System.out.println("Do you wish to continue? [y/n]:");
		String choice = scanner.next();
		shouldRepeat = choice.charAt(0)=='y' || choice.charAt(0)=='Y';
		return shouldRepeat;
	}
	
	public static Registration promptRegistration() {
		Registration registration = new Registration();
				
		String firstName="";
		while(!firstName.matches("[a-zA-Z ]+")) {
			System.out.println("Enter name: ");
			firstName = scanner.next();
		}
		registration.setCustomerName(firstName);
		
		String mobile="";
		while(!mobile.matches("\\d{10}")) {
			System.out.println("Enter mobile number: ");
			mobile = scanner.next();
		}
		registration.setMobileNo(mobile);
		
		double registrationFees=0;
		while(registrationFees<=0) {
			System.out.println("Enter Registration Fees: ");
			registrationFees = scanner.nextDouble();
		}
		registration.setRegistrationFees(registrationFees);
		
		int age=0;
		while(age<=0) {
			System.out.println("Enter Age: ");
			age = scanner.nextInt();
		}
		registration.setAge(age);
		
		logger.debug("Registration prompted.");
		return registration;
	}
	
	public static void printAcknowledgement(Registration registration) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("\n\n---------------------------------\n");
		sBuffer.append("Acknowledgement\n");
		sBuffer.append("Registration Id: "+registration.getRegistrationId()+"\n");
		sBuffer.append("Congratulation!!! "+registration.getCustomerName());
		sBuffer.append("\nThanks for taking part.\n");
		sBuffer.append("Fees paid : "+registration.getActualFees());
		sBuffer.append("\n---------------------------------\n\n");
		System.out.println(sBuffer.toString());
	}
	
	public static Registration createRegistration(Registration registration){
		IRegistrationService registrationService = new RegistrationServiceImpl();
		try {
			Registration registration2 = registrationService.createRegistration(registration);
			return registration2;
		} catch (InvalidAgeException e) {
			System.out.println("Invalid Age.");
//			e.printStackTrace();
		}
		return null;
	}
}
