package org.dao;

import org.game.model.Registration;

public interface IRegistrationDao {

	public Registration createRegistration(Registration registration);
}
