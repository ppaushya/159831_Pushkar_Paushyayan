package org.service;

import org.game.exception.InvalidAgeException;
import org.game.model.Registration;

public interface IRegistrationService {

	public Registration createRegistration(Registration registration) throws InvalidAgeException ;
}
