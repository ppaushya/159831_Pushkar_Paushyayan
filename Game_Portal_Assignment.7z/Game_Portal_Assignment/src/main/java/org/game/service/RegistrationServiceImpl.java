package org.service;

import org.apache.log4j.Logger;
import org.game.dao.IRegistrationDao;
import org.game.dao.RegistrationDaoImpl;
import org.game.exception.InvalidAgeException;
import org.game.model.Registration;

public class RegistrationServiceImpl implements IRegistrationService{

	final static Logger logger=Logger.getLogger(RegistrationDaoImpl.class);
	
	private IRegistrationDao registrationDao = new RegistrationDaoImpl();
	
	public RegistrationServiceImpl() {
		
	}
	
	public RegistrationServiceImpl(IRegistrationDao registrationDao) {
		this.registrationDao = registrationDao;
	}
	
	@Override
	public Registration createRegistration(Registration registration) throws InvalidAgeException {
		if(registration==null) {
			logger.error("IllegalArgumentException");
			throw new IllegalArgumentException();
		}
		if(registration.getAge()<10) {
			logger.error("InvalidAgeException at age="+registration.getAge());
			throw new InvalidAgeException("Invalid age.");
		}
		
		double actualFees = getActualFees(registration.getRegistrationFees(), registration.getAge());
		registration.setActualFees(actualFees);
		
		return registrationDao.createRegistration(registration);
	}
	
	public double getActualFees(double fees,int age) {
		double rate;
		if(age<=18) {
			rate = 0;
		}else if (age<=25) {
			rate = 10;
		}else if (age<=50) {
			rate = 20;
		}else {
			rate = 30;
		}
		return fees*(100+rate)/100;
	}

}
