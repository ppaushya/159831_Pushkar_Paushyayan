
# *************************************************************************
# ***              DO NOT TOUCH FILES IN THIS DIRECTORY!                ***
# *** FILES IN THIS DIRECTORY AND SUBDIRECTORIES CONSTITUTE A DERBY     ***
# *** DATABASE, WHICH INCLUDES THE DATA (USER AND SYSTEM) AND THE       ***
# *** FILES NECESSARY FOR DATABASE RECOVERY.                            ***
# *** EDITING, ADDING, OR DELETING ANY OF THESE FILES MAY CAUSE DATA    ***
# *** CORRUPTION AND LEAVE THE DATABASE IN A NON-RECOVERABLE STATE.     ***
# *************************************************************************