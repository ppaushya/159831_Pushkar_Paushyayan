package Assignment;

public class Address {

	private String stName;
	private String city;
	private String state;
	
}
