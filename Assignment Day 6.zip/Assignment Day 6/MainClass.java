package Assignment;
import java.util.*;
public class MainClass {
	public static void main(String[] args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number of customer:");
	int n=sc.nextInt();
	System.out.println("Enter details of "+ n +" customers.");
	Customer[] c=new Customer[n];
	
	}

}
