var myFunction=function(){
	console.log('Hello!Good Afetrnoon!')
}

myFunction();


var emp={
		empid:1001,
       firstName:'Tom',
       lastName:'Moody',
       salary: 23000
};
for(key in emp)
	{
	console.log(key);
	console.log('Key -> '+emp[key]);
	}
console.log(emp.empid);
console.log(emp.firstName);
console.log(emp.lastName);
console.log(emp.salary);
console.log(emp);