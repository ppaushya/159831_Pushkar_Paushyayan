function Employee(name)
{
	this.name=name
	
	}
Employee.prototype.getName=
	function(){
	return this.name
}
function Department(name,manager)
{
	this.name=name
	this.manager=manager
	}
Department.prototype.getDepName=
	function(){
	return this.name
}
var emp=new Employee('Abc')
var dep=new Department('sales','Bcde')
console.log(emp.getName())
console.log(dep.getDepName())

dep._proto_=emp
console.log(dep._proto_.getName());