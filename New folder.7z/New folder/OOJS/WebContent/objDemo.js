function Customer(custId,CustName,regFees,address){
this.custId=custId
this.CustName=CustName
this.regFees=regFees
this.address=address
this.printDetails=function(){
console.log(custId+'-'+CustName+'-'+regFees+'-'+address)
}
}

var customer=new Customer(1001,'Ram',2300.0,'23 North Avenue')
customer.printDetails()

