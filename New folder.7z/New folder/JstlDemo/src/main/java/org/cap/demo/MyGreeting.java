package org.cap.demo;

import java.io.IOException;
import java.time.LocalTime;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MyGreeting extends SimpleTagSupport {
	private String getName;
	private String nameColor;
	
	

	public void setGetName(String name) {
		this.getName = name;
	}



	public void setNameColor(String color) {
		this.nameColor = color;
	}



	@Override
	public void doTag() throws JspException, IOException {
		LocalTime time=LocalTime.now();
		int hrs=time.getHour();
		JspWriter out= getJspContext().getOut();
		
		if(this.getName==null)
			this.getName="Capgemini";
		
		if(hrs>1 && hrs<=10)
		{
			out.println("<h4>Good Morning <span style=\"color:"+nameColor+"\">" +getName +"</span></h4>");
		}
		else if(hrs>10 && hrs<=14)
		{
			out.println("<h4>Good Afternoon <span style=\"color:"+nameColor+"\">"  +getName +"</span></h4>");
		}
		else if(hrs>14)
		{
			out.println("<h4>Good Evening <span style=\"color:"+nameColor+"\">"  +getName +"</span></h4>");
		}
		
		
	}

	
}
