package com.cg.jpa;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="employee_info")
public class Employee {

	@Id
	private int EmpId;
	
	@Column(name="Fname" ,nullable=false)
	private String firstName;
	
	@Basic()
	private String lastName;
	private double salary;
	
	@Column(name="empemailId" ,unique=true)
	private String emailId;
	
	@Temporal(value=TemporalType.TIME)
	private Date dateOfJoining;
	
	@Transient
	private String empPassword;
	
	public Employee()
	{
		
	}
	
	
	
	
	public Employee(String firstName, String lastName, double salary, String emailId, Date dateOfJoining,
			String empPassword) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.emailId = emailId;
		this.dateOfJoining = dateOfJoining;
		this.empPassword = empPassword;
	}




	public Employee(int empId, String firstName, String lastName, double salary, String emailId, Date dateOfJoining,
			String empPassword) {
		super();
		EmpId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.emailId = emailId;
		this.dateOfJoining = dateOfJoining;
		this.empPassword = empPassword;
	}




	public Employee(int empId, String firstName, String lastName, double salary) {
		super();
		EmpId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}
	public int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	
	
	public String getEmailId() {
		return emailId;
	}




	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}




	public Date getDateOfJoining() {
		return dateOfJoining;
	}




	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}




	public String getEmpPassword() {
		return empPassword;
	}




	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}




	@Override
	public String toString() {
		return "Employee [EmpId=" + EmpId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", emailId=" + emailId + ", dateOfJoining=" + dateOfJoining + ", empPassword=" + empPassword + "]";
	}




	
	
	
}
