package com.cg.jpa;

import javax.persistence.Entity;

@Entity
public class Task extends Module{

	
	private String taskName;
	
	
	

	public Task(String moduleName, String taskName) {
		super(moduleName);
		this.taskName = taskName;
	}

	public Task() {
		
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	
	
}
