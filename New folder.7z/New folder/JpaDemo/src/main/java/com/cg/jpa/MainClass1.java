package com.cg.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass1 {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
        EntityManager entityManager=emf.createEntityManager();
        EntityTransaction transaction=entityManager.getTransaction();
        transaction.begin();
        
        
        CustomerCompositeKey compositeKey=new CustomerCompositeKey(11,"Ask-1001");
        Customer customer=new Customer(compositeKey,"Sam","Thomson");
        entityManager.persist(customer);
        transaction.commit();

	}

}
