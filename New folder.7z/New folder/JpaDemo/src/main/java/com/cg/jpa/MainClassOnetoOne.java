package com.cg.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClassOnetoOne {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
        EntityManager entityManager=emf.createEntityManager();
        EntityTransaction transaction=entityManager.getTransaction();
        transaction.begin();
        
        Customer1 customer=new Customer1(1001,"Jalwa");
        
        
        Address address=new Address(1002,"4th Avenue");
        
        entityManager.persist(customer);
        entityManager.persist(address);
        
        transaction.commit();

	}

}
