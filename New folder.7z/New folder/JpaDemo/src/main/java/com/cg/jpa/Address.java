package com.cg.jpa;

import javax.persistence.Entity;

import javax.persistence.OneToOne;

@Entity
public class Address {

	private int addressId;
	private String addressLine;
	
	@OneToOne
	private Customer customer;
	
	public Address(int addressId, String addressLine) {
		super();
		this.addressId = addressId;
		this.addressLine = addressLine;
	}
	
	public Address() {
		
	}

	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getAddressLine() {
		return addressLine;
	}
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", addressLine=" + addressLine + "]";
	}
	
	
	
}
