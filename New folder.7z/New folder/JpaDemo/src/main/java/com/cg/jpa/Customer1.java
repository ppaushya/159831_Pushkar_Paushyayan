package com.cg.jpa;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

@Entity
public class Customer1 {

	@Id
	private int customerId;
	@JoinColumn(name="Cust_fk")
	private String customerName;
	
	

	
	public Customer1(int customerId, String customerName) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	
	@Override
	public String toString() {
		return "Customer1 [customerId=" + customerId + ", customerName=" + customerName + "]";
	}
	
}
