package com.cg.jpa;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
        EntityManager entityManager=emf.createEntityManager();
        EntityTransaction transaction=entityManager.getTransaction();
        
        transaction.begin();
        
       
        Employee employee=new Employee(1001,"Jack","Sparrow",250000);
        employee.setDateOfJoining(new Date());
        
        Employee employee1=new Employee(1002,"Tom","Moody",260000);
        employee1.setDateOfJoining(new Date());
        
        
        Employee employee2=new Employee();
        employee2.setFirstName("Sajal");
        employee2.setLastName("Agarwal");
        employee2.setSalary(58000);
        employee2.setEmailId("jalwa@gmail.com");
        
        entityManager.persist(employee);
        entityManager.persist(employee1);
        entityManager.persist(employee2);
        transaction.commit();
	}

}
