package com.cg.mapping;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Company {

	@Id
	private int companyId;
	
	private String companyName;
	
	@OneToMany(mappedBy="company",targetEntity=EmployeeM.class)
	private List<EmployeeM> employees ;
	
	
	public Company(int companyId, String companyName, List<EmployeeM> employees) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.employees = employees;
	}
	public Company() {
		
	}
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public List<EmployeeM> getEmployees() {
		return employees;
	}
	public void setEmployees(List<EmployeeM> employees) {
		this.employees = employees;
	}
	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", employees=" + employees + "]";
	}
	
	
	
}
