package com.cg.mapping;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClassMany {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
        EntityManager entityManager=emf.createEntityManager();
        EntityTransaction transaction=entityManager.getTransaction();
        
        transaction.begin();
        
                        Company capg=new Company();
        
            			capg.setCompanyId(100);
            			capg.setCompanyName("Capgemini");
            			
            			Company tcs=new Company(); 
            	         tcs.setCompanyId(1001);
            	         tcs.setCompanyName("TCS");
            	         
            	         Company  cogni=new Company();
            	         cogni.setCompanyId(2001);
            	         cogni.setCompanyName("Cognizant");

            	         List<EmployeeM> employee=new ArrayList<>();
            	       
            	         EmployeeM  emp=new EmployeeM(1,"Monga",capg);
            	         EmployeeM emp1=new EmployeeM(2,"Raja",tcs);
            	         EmployeeM emp2=new EmployeeM(2,"Ram",cogni);
            	         entityManager.persist(emp);
            	         entityManager.persist(emp1);
            	         entityManager.persist(emp2);
            	         entityManager.persist(capg);
            	         entityManager.persist(tcs);
            	         entityManager.persist(cogni);
            	        
            	 	
        transaction.commit();
        entityManager.close();
	}

}
