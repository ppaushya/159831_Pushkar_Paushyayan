package com.capg.manytomany;

public class Event {

}
