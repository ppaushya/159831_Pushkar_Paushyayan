package com.capg.manytomany;

public class Delegates {

}
