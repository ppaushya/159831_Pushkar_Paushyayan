package com.cg.tcl;

public interface TransactionDao {
public void performTransaction();
}
