package com.cg.tcl;

public class TransactionDaoImpl implements TransactionDao{

	@Override
	public void performTransaction() {
		
		
		
	}

}
