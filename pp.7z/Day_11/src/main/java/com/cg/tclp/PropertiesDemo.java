package com.cg.tclp;

import java.util.Properties;

public class PropertiesDemo {

	public static void main(String[] args) {
	Properties  properties=new Properties();
//	properties.put(key, value);         
	}

}
