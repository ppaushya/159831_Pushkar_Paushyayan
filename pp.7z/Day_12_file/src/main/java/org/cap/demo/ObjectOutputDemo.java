package org.cap.demo;

import java.io.File;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class ObjectOutputDemo {

	public static void main(String[] args) {
		
		File file=new File("D:\\Users\\ppaushya\\Desktop\\Product.txt");
		
		try(OutputStream outputStream=new OutputStream(file);
				ObjectOutputStream obj=new ObjectOutputStream(outputStream))
		{
			
		}
		

	}

}
