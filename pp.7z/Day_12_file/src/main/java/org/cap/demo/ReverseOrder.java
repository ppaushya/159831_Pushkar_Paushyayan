package org.cap.demo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ReverseOrder {

	public static void main(String[] args) {
		File file=new File("D:\\Users\\ppaushya\\Desktop\\demo.txt");
		
		String greetings="Good Morning!";
		try(FileWriter writer =new FileWriter(file))
		{
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}

}
