package org.cap.demo;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		File file=new File("D:\\Users\\ppaushya\\Desktop\\demo.txt");

		if(file.isFile()) {
		if(file.exists()) {
			System.out.println("Readable : "+file.canRead());
			System.out.println("Writable : "+file.canWrite());
			System.out.println("Executable : "+file.canExecute());
			System.out.println("Path : "+file.getAbsolutePath());
		}
		else
		{
			System.out.println("File doesnot exist");
		}
		}else if(file.isDirectory())
	{
		String[] names=file.list();
		for(String name:names)
			System.out.println(name);}
		else {
			System.out.println("Sorry! No File/Directory exists");
			try {
				file.createNewFile();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
	}
}
