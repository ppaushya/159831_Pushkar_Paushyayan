package org.cap.demo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FormattedOutputDemo {
Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		String name;
		int id;
		int age;
		char gender;
		boolean isPermanent=true;

		File file=new File("D:\\Users\\ppaushya\\Desktop\\Employee.txt");
		
		try(FileOutputStream inp=new FileOutputStream(file);
				DataOutputStream inputStream=new DataOutputStream(inp))
		{
			
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}
