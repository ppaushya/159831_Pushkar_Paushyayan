package org.cap.demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderDemo {

	public static void main(String[] args) {
		FileReader in ;
		try
		{
			in=new FileReader("D:\\Users\\ppaushya\\Desktop\\demo.txt");
		
		BufferedReader reader=new BufferedReader(in);
		
		}
		catch(IOException e)
		{
			
		}
	}

}
