package org.cap.demo;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FormattedDemo {

	public static void main(String[] args) {
		String name;
		int id;
		int age;
		char gender;
		boolean isPermanent=true;

		File file=new File("D:\\Users\\ppaushya\\Desktop\\Employee.txt");
		
		try(FileInputStream inp=new FileInputStream(file);
				DataInputStream inputStream=new DataInputStream(inp))
		{
			
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}
