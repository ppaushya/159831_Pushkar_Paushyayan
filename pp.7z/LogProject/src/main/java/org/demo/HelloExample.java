package org.demo;

import org.apache.log4j.Logger;

public class HelloExample {

	final static Logger Logger1 = Logger.getLogger(HelloExample.class);
	
	public static void main(String[] args) {
		HelloExample obj=new HelloExample();
		obj.runMe("Capgemini");
	}
private void runMe(String parameter)
{
	if(Logger1.isDebugEnabled())
	{
		Logger1.debug("This is debug : " + parameter);
	}
	
	if (Logger1.isInfoEnabled())
	{
		Logger1.info("This is info : "+parameter);
	}
	
	Logger1.warn("This is warn :" + parameter);
	Logger1.error("This is error :" + parameter);
	Logger1.fatal("This is fatal :" + parameter);
	}
}
