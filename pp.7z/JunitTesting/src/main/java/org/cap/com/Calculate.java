package org.cap.com;

public class Calculate {

	
		public int addNumber(int n,int n2)
		{
			int sum=n+n2;
			return sum;
		}
public void runLoop()
{
	
}
	}

