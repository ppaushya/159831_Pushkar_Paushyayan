package org.cap.test;

import org.cap.account.model.Account;

public interface IAccountService {

	public Account createAccount(Customer customer,double amount) 
			throws InvalidAmountException;
}
