package org.cap.test;

public class InvalidAmountException extends Exception {
	public InvalidAmountException(String msg) {
		super(msg);
	}
}
