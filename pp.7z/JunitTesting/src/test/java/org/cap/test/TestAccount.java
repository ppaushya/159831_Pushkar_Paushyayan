package org.cap.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestAccount {

	@Test
	public void test_add_account() {
		IAccountService iac=new AccountServiceImpl();
		
	}

}
