package org.cap.test;

public interface IAccountDao {

	public boolean addAccount(Customer customer);

}
