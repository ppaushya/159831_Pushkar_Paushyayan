package org.cap.test;

public class AccountUtility {

	public static int generateAccountNo() {
		return (int)(Math.random()*1000);
	}

}
