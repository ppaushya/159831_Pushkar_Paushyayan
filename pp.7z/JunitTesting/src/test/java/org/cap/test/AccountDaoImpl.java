package org.cap.test;

public class AccountDaoImpl implements IAccountDao {

	@Override
	public boolean addAccount(Customer customer) {
		
		return false;
	}

}
