package org.cap.test;

import org.cap.account.model.Account;

public class AccountServiceImpl implements IAccountService {
	private IAccountDao accountDao=new AccountDaoImpl();

	public Account createAccount(Customer customer, double amount) throws InvalidAmountException {
		if(customer==null)
			throw new IllegalArgumentException("Invalid Customer!");
		if(amount<1000)
			throw new InvalidAmountException("Sorry! Invalid opening Balance!");
		Account account=new Account();
		account.setAccountType("savings");
		account.setBalance(amount);
		account.setAccountNo(AccountUtility.generateAccountNo());
		
		customer.setAccount(account);
		
		if(accountDao.addAccount(customer))
					return account;
		else
			return null;
	}

}
