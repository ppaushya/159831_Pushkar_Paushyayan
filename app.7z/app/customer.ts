export class Customer{
    customerId: number;
    firstName: string;
    lastName: string;
}