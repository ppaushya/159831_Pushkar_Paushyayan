import { Component, OnInit } from '@angular/core';
import {CustService} from '../cust.service';
import {Customer} from '../customer';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customers: Customer[];

  constructor(private custService: CustService) { }

  ngOnInit() {
    this.getCustomers();
  }

  getCustomers(): void{
    this.custService.getCustomers()
    .subscribe(customers => this.customers = customers);
  }

}
