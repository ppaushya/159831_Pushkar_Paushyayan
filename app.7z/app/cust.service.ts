import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import {Customer} from './customer';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class CustService {

  customers: Customer[];

  private custUrl = 'http://localhost:8080/day3-Spring5Rest/api/customers';  // URL to web api
  

  constructor(private http: HttpClient) { }


  getCustomers (): Observable<Customer[]> {
    console.log('Customers here!' + this.http.get<Customer[]>(this.custUrl))
    return this.http.get<Customer[]>(this.custUrl)
     
  }
}


