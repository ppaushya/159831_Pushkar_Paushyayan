package ConferenceRegistration;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {


	private WebDriver webdriver;
	  WebElement element;
	
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ppaushya\\selenium\\chromedriver.exe");
		 webdriver=new ChromeDriver();
	}
	

@Given("^Conference Registration page$")
public void conference_Registration_page() throws Throwable {
	webdriver.get("file:///C:/Users/ppaushya/Downloads/Conferencebooking/ConferenceRegistartion.html");
	
}

@When("^Verify title of the page$")
public void verify_title_of_the_page() throws Throwable {
	
	
	String title=webdriver.getTitle();
	assertEquals("Conference Registartion", title);
	/*if(title.equals("Conference Registration"))
	{
		
	}
	else
	{
		webdriver.quit();
	}*/
}

@When("^Verify heading of the page$")
public void verify_heading_of_the_page() throws Throwable {
	webdriver.findElement(By.xpath("/html/body/h4"));
	
}

@When("^Enter User details$")
public void enter_User_details() throws Throwable {
	webdriver.findElement(By.name("txtFN")).sendKeys("Pushkar");
	Thread.sleep(400);
	webdriver.findElement(By.name("txtLN")).sendKeys("Paushyayan");
	Thread.sleep(400);
	webdriver.findElement(By.name("Email")).sendKeys("push@gmail.com");
	Thread.sleep(400);
	webdriver.findElement(By.name("Phone")).sendKeys("9875463214");
	Thread.sleep(400);
	Select dropdown = new Select(webdriver.findElement(By.name("size")));
	dropdown.selectByVisibleText("3");
	Thread.sleep(400);
	webdriver.findElement(By.name("Address")).sendKeys(" Sk Nagar");
	webdriver.findElement(By.name("Address2")).sendKeys("Near Sk nagar Park 2");
	Thread.sleep(400);
	Select dropdown1 = new Select(webdriver.findElement(By.name("city")));
	dropdown1.selectByVisibleText("Pune");

	Select dropdown2 = new Select(webdriver.findElement(By.name("state")));
	dropdown2.selectByVisibleText("Maharashtra");
	Thread.sleep(400);
	WebElement radio1 = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[1]"));
	        //Radio Button1 is selected
	        radio1.click();
	        
	     WebElement radio2 = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[1]"));
	        //Radio Button1 is selected
	        radio2.click();
	        Thread.sleep(400);
}

@When("^click next button$")
public void click_next_button() throws Throwable {
WebElement click = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
    
    click.click();
   
    Alert alert = webdriver.switchTo().alert();
  
 alert.accept();
}

@Then("^Navigate to Payment Details page$")
public void navigate_to_Payment_Details_page() throws Throwable {
	webdriver.navigate().to("file:///C:/Users/ppaushya/Downloads/Conferencebooking/PaymentDetails.html");
	Thread.sleep(1000);
  
}



@Given("^Payment Details page$")
public void payment_Details_page() throws Throwable {
 
	webdriver.navigate().to("file:///C:/Users/ppaushya/Downloads/Conferencebooking/PaymentDetails.html");
	Thread.sleep(1000);
  

} 


@When("^payment details entered$")
public void payment_details_entered() throws Throwable {
	webdriver.findElement(By.name("txtFN")).sendKeys("Pushkar Paushyayan");
	webdriver.findElement(By.name("debit")).sendKeys("4386280528246586");
	webdriver.findElement(By.name("cvv")).sendKeys("786");
	webdriver.findElement(By.name("month")).sendKeys("12");
	webdriver.findElement(By.name("year")).sendKeys("21");
	
	/*WebElement makepayment = webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));	
	
	makepayment.click();*/
}

@When("^Click Register button$")
public void click_Register_button() throws Throwable {
WebElement payment = webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));	
	
	payment.click();
	
    Alert alert = webdriver.switchTo().alert();
  
 alert.accept();
 Thread.sleep(1000);
	webdriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	
}



@After
public void tearDown()
{
	webdriver.quit();
}
}
