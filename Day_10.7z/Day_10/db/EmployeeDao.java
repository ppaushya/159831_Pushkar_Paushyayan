package org.cap.db;

import java.time.LocalDate;
import java.util.List;

public interface EmployeeDao {
	
	public void createEmployee(Employee employee);
	public void deleteEmployee(int employeeId);
	
	public List<Employee>  getAllEmployees();
	public Employee findEmployee(int employeeId);
	public void updateFirstName(int empId1, String fname);
	public void updateLastName(int empId1, String lname);
	public void updateSalary(int empId1, double sal);
	public void updateDate(int empId1, LocalDate date);

}
