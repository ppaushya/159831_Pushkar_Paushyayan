package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Customer;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ILoginService loginService=new LoginServiceImpl();
		
		//capturing data
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String dateofbirth=request.getParameter("dateofbirth");
		String mobileNumber=request.getParameter("mobileNumber");
		String emailId=request.getParameter("emailId");
		String password=request.getParameter("password");
		
		
		Customer customer1=new Customer();
		
		customer1.setFirstName(firstName);
		customer1.setLastName(lastName);
		
        String[] date=dateofbirth.split("-");
		
		customer1.setDateofbirth(LocalDate.of(Integer.parseInt(date[0]), Integer.parseInt(date[1]),
				Integer.parseInt(date[2]))); 
		customer1.setMobileNumber(mobileNumber);
		customer1.setEmailId(emailId);
		customer1.setPassword(password);
		
		Customer customer =loginService.createCustomer( customer1);
		if(customer!=null)
		{
		PrintWriter out=response.getWriter();
		out.println(" Customer Registered");
		}
	else
		response.sendRedirect("index.html"); 
	}

}
