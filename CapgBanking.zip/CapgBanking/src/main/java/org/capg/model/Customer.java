package org.capg.model;

import java.time.LocalDate;

public class Customer {
	
private String firstName;
private String lastName;
private LocalDate dateofbirth;
private String mobileNumber;
private String emailId;
private String password;

public Customer()
{
	
}
public Customer(String firstName, String lastName, LocalDate dateofbirth, String mobileNumber, String emailId,String password) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.dateofbirth = dateofbirth;
	this.mobileNumber = mobileNumber;
	this.emailId=emailId;
	this.password = password;
	
	
	
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public LocalDate getDateofbirth() {
	return dateofbirth;
}
public void setDateofbirth(LocalDate dateofbirth) {
	this.dateofbirth = dateofbirth;
}
public String getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Override
public String toString() {
	return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", dateofbirth=" + dateofbirth
			+ ", mobileNumber=" + mobileNumber + ", emailId=" + emailId + ", password=" + password + "]";
}


}
