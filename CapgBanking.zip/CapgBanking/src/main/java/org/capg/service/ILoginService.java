package org.capg.service;

import org.capg.model.LoginBean;

import java.util.Set;

import org.capg.model.Customer;

public interface ILoginService {
	
	public boolean isValidLogin(LoginBean loginBean);
	Customer createCustomer(Customer customer);
	Set<Customer> getAllCustomer();
}
