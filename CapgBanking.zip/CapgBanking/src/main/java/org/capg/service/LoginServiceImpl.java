package org.capg.service;

import java.util.Set;

import org.capg.dao.ILoginDao;
import org.capg.dao.LoginDaoImpl;
import org.capg.model.Customer;
import org.capg.model.LoginBean;





public class LoginServiceImpl implements ILoginService{

	private ILoginDao loginDao=new LoginDaoImpl();
	
	@Override
	public boolean isValidLogin(LoginBean loginBean) {
	
		
		if(loginDao.isValidLogin(loginBean))
			return true;
		
		return false;
	}

	@Override
	public Customer createCustomer(Customer customer) {
		ILoginDao loginDao=new LoginDaoImpl();
		return loginDao.createCustomer(customer);
		
	}

	@Override
	public Set<Customer> getAllCustomer() {
		ILoginDao loginDao=new LoginDaoImpl();
		return loginDao.getAllCustomer();
	}
}
