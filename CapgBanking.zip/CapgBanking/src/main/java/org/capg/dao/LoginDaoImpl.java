package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.capg.model.Customer;
import org.capg.model.LoginBean;

public class LoginDaoImpl implements ILoginDao{

	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		
		String sql="select * from customer where emailId=? and customerPwd=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setString(1, loginBean.getUserName());
			pst.setString(2, loginBean.getUserPassword());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	
	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "admin");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return conn;
		
	}


	@Override
	public Customer createCustomer(Customer customer) {
		String query = "INSERT INTO customer (firstName ,lastName,dateofbirth,emailId,mobileNumber,password) VALUES(?,?,?,?,?,?)";
		try(Connection connection = getMysqlDbConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			//statement.setInt(1,customer.getCustomerId());
			statement.setString(1,customer.getFirstName());
			statement.setString(2,customer.getLastName());
			statement.setDate(3,java.sql.Date.valueOf(customer.getDateofbirth()));
			statement.setString(4, customer.getEmailId());
			statement.setString(5, customer.getMobileNumber());
			statement.setString(6, customer.getPassword());
			
			int count = statement.executeUpdate();
			if(count>0) {
				System.out.println("Customer details inserted");
				query="select * from customer";
				statement=connection.prepareStatement(query);
				ResultSet resultSet= statement.executeQuery();
				Customer  customer1=new Customer();
				while(resultSet.next()) {
					//customer1.setCustomerId(resultSet.getInt(1));
					customer1.setFirstName(resultSet.getString(1));
					customer1.setLastName(resultSet.getString(2));
					customer1.setDateofbirth(resultSet.getDate(3).toLocalDate());
					customer1.setEmailId(resultSet.getString(4));
					customer1.setMobileNumber(resultSet.getString(5));
					customer1.setPassword(resultSet.getString(6));
				}
				return customer1;
			}else {System.out.println("Error occured.");}
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public Set<Customer> getAllCustomer() {
		Set<Customer> customers=new HashSet<>();
		Customer customer=new Customer();
		String query="select * from customer";
		try(Connection connection = getMysqlDbConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
		statement=connection.prepareStatement(query);
		ResultSet resultSet= statement.executeQuery();
		while(resultSet.next()) {
			//customer.setCustomerId(resultSet.getInt(1));
			customer.setFirstName(resultSet.getString(1));
			customer.setLastName(resultSet.getString(2));
			customer.setDateofbirth(resultSet.getDate(3).toLocalDate());
			customer.setEmailId(resultSet.getString(4));
			customer.setMobileNumber(resultSet.getString(5));
			customer.setPassword(resultSet.getString(6));
			customers.add(customer);
		}
		
		return customers;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

}
