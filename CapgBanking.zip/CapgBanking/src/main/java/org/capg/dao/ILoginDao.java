package org.capg.dao;

import java.util.Set;

import org.capg.model.Customer;
import org.capg.model.LoginBean;

public interface ILoginDao {
	public boolean isValidLogin(LoginBean loginBean);

	public Customer createCustomer(Customer customer);
	Set<Customer> getAllCustomer();

}
